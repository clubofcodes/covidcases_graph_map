# Covid cases in graph and map

This project contains a line graph showing the case fluctuations. 
And a react leaflet map with markers that indicates the country name, the total number of active, recovered cases, and deaths in that particular country as a popup.
